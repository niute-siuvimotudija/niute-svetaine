# NIUTE svetainė

Tai statinis, mobiliesiems pritaikytas NIUTE drabužių taisymo paštu svetainės prototipas.

## Paleidimas
1. Išarchyvuokite ZIP failą.
2. Atidarykite `index.html` naršyklėje.

## Prieš viešinant pakeiskite
- el. paštą `labas@niute.lt`;
- orientacines kainas;
- siuntimo ir grąžinimo taisykles;
- privatumo politiką ir verslo rekvizitus;
- užsakymo formą prijunkite prie el. pašto, Formspree, Shopify, WooCommerce ar kitos sistemos.

Nuotraukos įkėlimas šiame prototipe yra demonstracinis.
