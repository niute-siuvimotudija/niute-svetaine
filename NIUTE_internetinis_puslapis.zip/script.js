document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("orderForm");
const message = document.getElementById("formMessage");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }

  message.textContent = "Ačiū! Jūsų užklausa paruošta. Tikroje svetainėje ji būtų išsiųsta NIUTE komandai.";
  form.reset();
});
